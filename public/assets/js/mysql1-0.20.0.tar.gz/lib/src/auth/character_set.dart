library mysql1.character_set;

class CharacterSet {
  static const int UTF8 = 33;
  static const int UTF8MB4 = 45;
}
